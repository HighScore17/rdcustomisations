<?php
/**
*  * Customer completed order email
*   *
*    * This template can be overridden by copying it to yourtheme/woocommerce/emails/customer-completed-order.php.
*     *
*      * HOWEVER, on occasion WooCommerce will need to update template files and you
*       * (the theme developer) will need to copy the new files to your theme to
*        * maintain compatibility. We try to do this as little as possible, but it does
*         * happen. When this occurs the version of the template file will be bumped and
*          * the readme will list any important changes.
*           *
*            * @see https://docs.woocommerce.com/document/template-structure/
*             * @package WooCommerce\Templates\Emails
*              * @version 3.7.0
*               */

if ( ! defined( 'ABSPATH' ) ) {
		exit;
}

/*
	*  * @hooked WC_Emails::email_header() Output the email header
	*   */
do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<table
	border="0"
	cellpadding="0"
	cellspacing="0"
	width="100%"
	id="templateBody"
>
	<tr>
	<td valign="top" class="bodyContent" mc:edit="body_content">
		<h1>Order Completed</h1>
		<h2>Hello <?= $order->get_billing_first_name(); ?>,</h2>
	</td>
	</tr>
	<tr>
	<td valign="top" class="bodyContent" mc:edit="body_content">
		Your order has been successfully delivered to the following address:
	</td>
	</tr>
</table>

<table
	border="0"
	cellpadding="0"
	cellspacing="0"
	width="50%"
	id="templateColumnsLeft"
>
	<tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="50%"
		mc:edit="left_column_content"
	>
		<h3>Received by:</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="50%"
		mc:edit="right_column_content"
	>
		<?= $order->get_shipping_first_name() . " " . $order->get_shipping_last_name();  ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="50%"
		mc:edit="left_column_content"
	>
		<h3>Date:</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="50%"
		mc:edit="right_column_content"
	>
		<?= wc_format_datetime( $order->get_date_completed() ) ?>
	</td>
	</tr>
  <tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="50%"
		mc:edit="left_column_content"
	>
		<h3>Hour:</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="50%"
		mc:edit="right_column_content"
	>
		<?= wc_format_datetime( $order->get_date_completed(), 'g:i A' ) ?>
	</td>
	</tr>
</table>

<?php

/*
	*  * @hooked WC_Emails::order_details() Shows the order details table.
	*   * @hooked WC_Structured_Data::generate_order_data() Generates structured data.
	*    * @hooked WC_Structured_Data::output_structured_data() Outputs structured data.
	*     * @since 2.5.0
	*      */
do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

?>

<table
	border="0"
	cellpadding="0"
	cellspacing="0"
	width="100%"
	id="templateBody"
>
	<tr>
		<td valign="top" class="bodyContent" mc:edit="body_content">
			If you need help or have any questions about your delivery, you can answer this email or send one to sales@rocket.direct
		</td>
	</tr>
	<tr>
		<td valign="top" class="bodyContent" mc:edit="body_content">
			It has been a pleasure to serve you and your team. We hope to continue to be your PPE supplier of choice.
		</td>
	</tr>
	<tr>
    <td valign="top" class="bodyContent" mc:edit="body_content">
      - The rocket.direct Team
    </td>
	</tr>
</table>
<?php


/*
	*  * @hooked WC_Emails::email_footer() Output the email footer
	*   */
do_action( 'woocommerce_email_footer', $email );

