<?php
/**
*  * Email Footer
*   *
*    * This template can be overridden by copying it to yourtheme/woocommerce/emails/email-footer.php.
*     *
*      * HOWEVER, on occasion WooCommerce will need to update template files and you
*       * (the theme developer) will need to copy the new files to your theme to
*        * maintain compatibility. We try to do this as little as possible, but it does
*         * happen. When this occurs the version of the template file will be bumped and
*          * the readme will list any important changes.
*           *
*            * @see https://docs.woocommerce.com/document/template-structure/
*             * @package WooCommerce\Templates\Emails
*              * @version 3.7.0
*               */

defined( 'ABSPATH' ) || exit;
?>
			<table
              border="0"
              cellpadding="0"
              cellspacing="0"
              width="100%"
              id="templateFooter"
            >
              <tr>
                <td
                  valign="bottom"
                  class="footerContent"
                  mc:edit="footer_content00"
                  align="center"
                >
                  <hr />
                </td>
              </tr>
              <tr>
                <td
                  valign="bottom"
                  class="footerContent"
                  mc:edit="footer_content00"
                  align="center"
                >
                  <a href="https://www.linkedin.com/company/rocket-direct">
                    <img
                      style="
                        width: 25px;
                        padding-right: 15px;
                        padding-left: 15px;
                      "
                      src="https://wp.rocket.direct/wp-content/uploads/2021/01/Group-6.png"
                  /></a>
                </td>
              </tr>

              <tr>
                <td
                  valign="bottom"
                  class="footerContent"
                  mc:edit="footer_content00"
                  align="center"
                >
                  Email us at:
                  <br /><a href="mailto:customercare@rocket.direct"
                    >customercare@rocket.direct</a
                  >
                </td>
              </tr>
            </table>

            <!-- // END FOOTER -->

            <!-- BEGIN FOOTER // -->
            <table
              border="0"
              cellpadding="0"
              cellspacing="0"
              width="100%"
              id="templateCredits"
            >
              <tr>
                <td
                  valign="center"
                  class="creditsContent"
                  mc:edit="credits_content00"
                  align="center"
                >
                  2020 Rocket Distributors, LLC
                </td>
              </tr>
            </table>

            <!-- // END FOOTER -->
          </td>
        </tr>
      </table>
    </center>
  </body>
</html>

