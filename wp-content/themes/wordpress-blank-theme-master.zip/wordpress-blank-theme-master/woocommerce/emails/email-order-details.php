<?php
/**
*  * Order details table shown in emails.
*   *
*    * This template can be overridden by copying it to yourtheme/woocommerce/emails/email-order-details.php.
*     *
*      * HOWEVER, on occasion WooCommerce will need to update template files and you
*       * (the theme developer) will need to copy the new files to your theme to
*        * maintain compatibility. We try to do this as little as possible, but it does
*         * happen. When this occurs the version of the template file will be bumped and
*          * the readme will list any important changes.
*           *
*            * @see https://docs.woocommerce.com/document/template-structure/
*             * @package WooCommerce\Templates\Emails
*              * @version 3.7.0
*               */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text, $email ); ?>



<!-- Order information -->


<?php foreach( $order->get_items() as $item_id => $item ) : ?>
	<table
	border="0"
	cellpadding="0"
	cellspacing="0"
	width="50%"
	id="templateColumnsLeft"
>
	<tr mc:repeatable>
	<th
		valign="center"
		class="rightColumnContent"
		width="100%"
		mc:edit="right_column_content"
		colspan="100%"
	>
		<h3>ORDER SUMMARY</h3>
		<br />
	</th>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="50%"
		mc:edit="left_column_content"
	>
		<h3>Order Number:</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="50%"
		mc:edit="right_column_content"
	>
		<?= $order->get_order_number();  ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="50%"
		mc:edit="left_column_content"
	>
		<h3>Order Date:</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="50%"
		mc:edit="right_column_content"
	>
		<?= wc_format_datetime( $order->get_date_created() ) ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="50%"
		mc:edit="left_column_content"
	>
		<h3>Product Name</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="50%"
		mc:edit="right_column_content"
	>
		<?= $item->get_name(); ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="35%"
		mc:edit="left_column_content"
	>
		<h3>Order Qty:</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?= $item->get_quantity(); ?> units
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="leftColumnContent"
		width="35%"
		mc:edit="left_column_content"
	>
		<h3>Order Total:</h3>
	</td>

	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?php $item->get_total(); ?>
	</td>
	</tr>
</table>

<!-- Shipping Information -->
<table
	border="0"
	cellpadding="0"
	cellspacing="0"
	width="50%"
	id="templateColumnsRight"
>
	<tr mc:repeatable>
	<th
		valign="center"
		class="rightColumnContent"
		width="100%"
		mc:edit="right_column_content"
		colspan="100%"
	>
		<h3>SHIPPING INFORMATION</h3>
		<br />
	</th>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?= $order->get_shipping_first_name() . " " . $order->get_shipping_last_name(); ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?= $order->get_shipping_company(); ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?= $order->get_shipping_address_1(); ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?= $order->get_shipping_address_2(); ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?= $order->get_shipping_city() . ", " . $order->get_shipping_state(); ?>
	</td>
	</tr>
	<tr mc:repeatable>
	<td
		valign="center"
		class="rightColumnContent"
		width="65%"
		mc:edit="right_column_content"
	>
		<?= $order->get_shipping_postcode() . ", " . $order->get_shipping_country(); ?>
	</td>
	</tr>
</table>
<?php endforeach; ?>
<!-- // END BODY -->
<?php do_action( 'woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text, $email ); ?>
